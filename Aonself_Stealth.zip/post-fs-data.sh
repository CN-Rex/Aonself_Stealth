#!/system/bin/sh

rp() {
    command resetprop "$@" 2>/dev/null \
        || /data/adb/magisk/resetprop "$@" 2>/dev/null \
        || /data/adb/ksu/bin/resetprop "$@" 2>/dev/null \
        || true
}

CONF=/data/adb/Aonself_Stealth/config.ini
hide_root=1
hide_bl=1
hide_tee=1
[ -f "$CONF" ] && . "$CONF" 2>/dev/null

if [ "$hide_root" = "1" ]; then
    rp ro.debuggable 0
    rp ro.secure 1
fi

if [ "$hide_bl" = "1" ]; then
    rp ro.boot.verifiedbootstate green
    rp ro.boot.vbmeta.device_state locked
    rp ro.boot.flash.locked 1
    rp ro.boot.warranty_bit 0
    rp ro.secureboot.lockstate locked
    rp ro.boot.secureboot 1
    rp ro.boot.veritymode enforcing
    rp ro.boot.verifiedboot 1
    rp ro.boot.vbmeta.verifiedbootstate green
    rp ro.build.tags release-keys
fi

if [ "$hide_tee" = "1" ]; then
    rp ro.boot.tee_state 0
    rp ro.boot.teegist 0
    rp sys.tee.state ok
    rp vendor.tee.state ok
    rp ro.knox.sys.knox_ver 0
    rp ro.boot.warranty_verified 0
fi

exit 0