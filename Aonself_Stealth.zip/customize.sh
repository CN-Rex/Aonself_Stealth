#!/system/bin/sh
# Aonself Stealth 安装脚本 (v2.0 target.txt 版)
LOG=/data/adb/Aonself_Stealth/install.log
mkdir -p /data/adb/Aonself_Stealth 2>/dev/null
echo "== $(date '+%F %T') install begin ==" >> "$LOG" 2>&1

ui_print() { echo "$1"; }

MODDIR=${MODDIR:-/data/adb/modules/Aonself_Stealth}
ui_print "- [Aonself Stealth] 开始安装..."

# 1. 脚本执行权限（KSU 要求 customize.sh 可执行）
chmod 755 "$MODDIR/customize.sh" "$MODDIR/service.sh" "$MODDIR/post-fs-data.sh" 2>/dev/null
ui_print "- 脚本权限已修正 (755)"

# 2. 检查 Zygisk 环境
ui_print "- 检查 Zygisk 环境..."
if [ -d /data/adb/modules/zygisksu ]; then
    ui_print "- OK: 已检测到 Zygisk Next"
elif [ -n "$(magisk -v 2>/dev/null)" ]; then
    ui_print "- OK: 已检测到 Magisk 内置 Zygisk"
else
    ui_print "! 未检测到 Zygisk 环境"
    ui_print "! 模块需要 Zygisk API 才能生效"
    ui_print "! 请自行安装 Zygisk Next（官方 GitHub: Dr-TSNG/ZygiskNext）"
fi

# 3. 部署运行目录
ui_print "- 部署运行目录 /data/adb/Aonself_Stealth/"
mkdir -p /data/adb/Aonself_Stealth 2>/dev/null

# 4. keybox 占位（保留，供后续替换）
if [ -f "$MODDIR/keybox.xml" ]; then
    cp -f "$MODDIR/keybox.xml" /data/adb/Aonself_Stealth/keybox.xml 2>/dev/null
    ui_print "- keybox 占位已就位（可替换）"
fi

# 5. 部署 target.txt（目标应用配置）
if [ -f "$MODDIR/target.txt" ]; then
    cp -f "$MODDIR/target.txt" /data/adb/Aonself_Stealth/target.txt 2>/dev/null
    ui_print "- target.txt 已部署"
    ui_print "- 编辑 /data/adb/Aonself_Stealth/target.txt 或模块内 target.txt 添加目标包名"
fi

# 6. 全局属性伪装兜底配置（可选）
if [ ! -f /data/adb/Aonself_Stealth/config.ini ]; then
    cat > /data/adb/Aonself_Stealth/config.ini <<'EOF'
hide_bl=1
hide_tee=1
EOF
    ui_print "- 已生成默认全局伪装配置 config.ini"
fi

ui_print "- [Aonself Stealth] 安装完成！重启后生效"
ui_print "- 使用说明：在 target.txt 中每行写入一个包名（# 开头为注释）"
ui_print "- 重启后仅对这些应用生效（进程级伪装）"
echo "== $(date '+%F %T') install done ==" >> "$LOG" 2>&1
