#ifndef ANDROID_LOG_H
#define ANDROID_LOG_H
#include <stdio.h>
#define ANDROID_LOG_DEBUG 3
static inline int __android_log_print(int p, const char *t, const char *f, ...) { (void)p; (void)t; (void)f; return 0; }
#endif
