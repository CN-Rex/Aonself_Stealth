#!/system/bin/sh
# Aonself Stealth - 运行时文件兜底 (v2.0)
DIR=/data/adb/Aonself_Stealth
mkdir -p "$DIR" 2>/dev/null

# keybox 兜底
if [ ! -f "$DIR/keybox.xml" ]; then
    [ -f "$MODDIR/keybox.xml" ] && cp -f "$MODDIR/keybox.xml" "$DIR/keybox.xml" 2>/dev/null
    [ -f /data/adb/modules/Aonself_Stealth/keybox.xml ] && cp -f /data/adb/modules/Aonself_Stealth/keybox.xml "$DIR/keybox.xml" 2>/dev/null
fi

# target.txt 兜底（用户改模块内文件后重启即同步）
if [ ! -f "$DIR/target.txt" ] && [ -f /data/adb/modules/Aonself_Stealth/target.txt ]; then
    cp -f /data/adb/modules/Aonself_Stealth/target.txt "$DIR/target.txt" 2>/dev/null
fi

exit 0
