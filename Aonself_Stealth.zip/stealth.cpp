#include <jni.h>
#include <android/log.h>
#include <cstdarg>
#include <cstdio>
#include <cstring>
#include <cerrno>
#include <string>
#include <set>
#include <fcntl.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/sysmacros.h>
#include <sys/syscall.h>
#include "api.hpp"

#define LOG_TAG "Aonself"
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__)

using namespace zygisk;

// ================= 敏感路径（root痕迹） =================
static const char *SENSITIVE_PATHS[] = {
    "/data/adb",
    "/sbin/.magisk",
    "/sbin/su",
    "/system/bin/su",
    "/system/xbin/su",
    "/vendor/bin/su",
    "/su/bin",
    "/data/local/tmp",
    "/data/local/bin",
    "/cache/magisk",
    "/persist/magisk",
    "magisk",
    "supersu",
    "busybox",
    "kingroot",
    "frida",
    "xposed",
    "riru",
    "lsposed",
    "zygisksu",
    "zygisk_next",
    "shadowtee",
};

static bool is_sensitive(const char *path) {
    if (path == nullptr || path[0] == '\0') return false;
    for (size_t i = 0; i < sizeof(SENSITIVE_PATHS) / sizeof(SENSITIVE_PATHS[0]); ++i) {
        if (strstr(path, SENSITIVE_PATHS[i]) != nullptr) return true;
    }
    return false;
}

// ================= 伪装属性（BL锁 / TEE / root调试） =================
struct FakeProp { const char *name; const char *value; };
static const FakeProp FAKE_PROPS[] = {
    // BL 锁状态
    { "ro.boot.verifiedbootstate",       "green" },
    { "ro.boot.vbmeta.device_state",     "locked" },
    { "ro.boot.vbmeta.verifiedbootstate","green" },
    { "ro.boot.flash.locked",            "1" },
    { "ro.boot.warranty_bit",            "0" },
    { "ro.secureboot.lockstate",         "locked" },
    { "ro.boot.secureboot",              "1" },
    { "ro.boot.veritymode",              "enforcing" },
    { "ro.boot.verifiedboot",            "1" },
    { "ro.build.tags",                   "release-keys" },
    // TEE 状态
    { "ro.boot.tee_state",               "0" },
    { "ro.boot.teegist",                 "0" },
    { "sys.tee.state",                   "ok" },
    { "vendor.tee.state",                "ok" },
    { "ro.knox.sys.knox_ver",            "0" },
    { "ro.boot.warranty_verified",       "0" },
    // root 调试痕迹
    { "ro.debuggable",                   "0" },
    { "ro.secure",                       "1" },
};

// ================= 文件/目录访问 hook =================
static int (*real_openat)(int, const char *, int, ...) = nullptr;
static int fake_openat(int dirfd, const char *path, int flags, ...) {
    if (path != nullptr && is_sensitive(path)) { errno = ENOENT; return -1; }
    mode_t mode = 0;
    if (flags & O_CREAT) {
        va_list ap; va_start(ap, flags);
        mode = static_cast<mode_t>(va_arg(ap, int));
        va_end(ap);
    }
    return real_openat(dirfd, path, flags, mode);
}

static int (*real_open)(const char *, int, ...) = nullptr;
static int fake_open(const char *path, int flags, ...) {
    if (path != nullptr && is_sensitive(path)) { errno = ENOENT; return -1; }
    mode_t mode = 0;
    if (flags & O_CREAT) {
        va_list ap; va_start(ap, flags);
        mode = static_cast<mode_t>(va_arg(ap, int));
        va_end(ap);
    }
    return real_open(path, flags, mode);
}

static int (*real_stat)(const char *, struct stat *) = nullptr;
static int fake_stat(const char *path, struct stat *buf) {
    if (path != nullptr && is_sensitive(path)) { errno = ENOENT; return -1; }
    return real_stat(path, buf);
}

static int (*real_lstat)(const char *, struct stat *) = nullptr;
static int fake_lstat(const char *path, struct stat *buf) {
    if (path != nullptr && is_sensitive(path)) { errno = ENOENT; return -1; }
    return real_lstat(path, buf);
}

static int (*real_fstatat)(int, const char *, struct stat *, int) = nullptr;
static int fake_fstatat(int dirfd, const char *path, struct stat *buf, int flags) {
    if (path != nullptr && is_sensitive(path)) { errno = ENOENT; return -1; }
    return real_fstatat(dirfd, path, buf, flags);
}

static int (*real_access)(const char *, int) = nullptr;
static int fake_access(const char *path, int mode) {
    if (path != nullptr && is_sensitive(path)) { errno = ENOENT; return -1; }
    return real_access(path, mode);
}

static int (*real_faccessat)(int, const char *, int, int) = nullptr;
static int fake_faccessat(int dirfd, const char *path, int amode, int flags) {
    if (path != nullptr && is_sensitive(path)) { errno = ENOENT; return -1; }
    return real_faccessat(dirfd, path, amode, flags);
}

static ssize_t (*real_readlink)(const char *, char *, size_t) = nullptr;
static ssize_t fake_readlink(const char *path, char *buf, size_t size) {
    if (path != nullptr && is_sensitive(path)) { errno = ENOENT; return -1; }
    return real_readlink(path, buf, size);
}

static ssize_t (*real_readlinkat)(int, const char *, char *, size_t) = nullptr;
static ssize_t fake_readlinkat(int dirfd, const char *path, char *buf, size_t size) {
    if (path != nullptr && is_sensitive(path)) { errno = ENOENT; return -1; }
    return real_readlinkat(dirfd, path, buf, size);
}

// ================= Keybox attestation 伪装（C++ 实现） =================
#include <sys/ioctl.h>
#include <cstdlib>
#include <vector>

// ---- binder 协议常量（kernel/binder.h 子集） ----
#define BINDER_WRITE_READ _IOWR('b', 1, struct binder_write_read)
#define BC_TRANSACTION    _IOW('c', 0, struct binder_transaction_data)
#define BR_REPLY          _IOR('r', 3, struct binder_transaction_data)

struct binder_write_read {
    size_t write_size;
    size_t write_consumed;
    void *write_buffer;
    size_t read_size;
    size_t read_consumed;
    void *read_buffer;
};

struct binder_transaction_data {
    union { size_t handle; void *ptr; } target;
    void *cookie;
    uint32_t code;
    uint32_t flags;
    pid_t sender_pid;
    uid_t sender_euid;
    size_t data_size;
    size_t offsets_size;
    union {
        struct { const void *buffer; const void *offsets; } ptr;
        uint8_t buf[16];
    } data;
};

// ---- keybox.xml 解析：提取证书链（base64 DER） ----
static std::vector<std::vector<uint8_t>> g_keybox_certs;

static int b64val(char c) {
    if (c >= 'A' && c <= 'Z') return c - 'A';
    if (c >= 'a' && c <= 'z') return c - 'a' + 26;
    if (c >= '0' && c <= '9') return c - '0' + 52;
    if (c == '+') return 62;
    if (c == '/') return 63;
    return -1;
}

static std::vector<uint8_t> base64_decode(const std::string &in) {
    std::vector<uint8_t> out;
    int buf = 0, bits = 0;
    for (char c : in) {
        if (c == '=') break;
        int v = b64val(c);
        if (v < 0) continue;  // 忽略换行/空格
        buf = (buf << 6) | v;
        bits += 6;
        if (bits >= 8) {
            bits -= 8;
            out.push_back((uint8_t)((buf >> bits) & 0xFF));
        }
    }
    return out;
}

static void load_keybox() {
    g_keybox_certs.clear();
    const char *paths[] = {
        "/data/adb/Aonself_Stealth/keybox.xml",
        "/data/adb/modules/Aonself_Stealth/keybox.xml",
    };
    for (const char *p : paths) {
        FILE *f = fopen(p, "re");
        if (f == nullptr) continue;
        std::string xml;
        char buf[4096];
        size_t n;
        while ((n = fread(buf, 1, sizeof(buf), f)) > 0) xml.append(buf, n);
        fclose(f);
        // 只取第一个 <Key> 内的 CertificateChain（兼容 <Certificate> 与 <Certificate format="pem">）
        size_t key_start = xml.find("<Key");
        if (key_start == std::string::npos) key_start = 0;
        // 只取第一个 <Key> 的链（防止 ecdsa+rsa 双链混合）
        size_t key_end = xml.find("</Key>", key_start);
        if (key_end == std::string::npos) key_end = xml.size();
        size_t pos = key_start;
        const std::string tag_open = "<Certificate";
        const std::string tag_close = "</Certificate>";
        while (true) {
            size_t a = xml.find(tag_open, pos);
            if (a == std::string::npos || a > key_end) break;
            // 防止误匹配 <CertificateChain（后一个字符是字母则跳过）
            if (a + tag_open.size() < xml.size() &&
                isalpha((unsigned char)xml[a + tag_open.size()])) {
                pos = a + tag_open.size();
                continue;
            }
            size_t gt = xml.find('>', a);
            if (gt == std::string::npos) break;
            a = gt + 1;  // 标签结束
            size_t b = xml.find(tag_close, a);
            if (b == std::string::npos) break;
            std::string body = xml.substr(a, b - a);
            // 兼容 PEM：提取 BEGIN/END 之间的 base64 行
            size_t pem = body.find("-----BEGIN CERTIFICATE-----");
            if (pem != std::string::npos) {
                body = body.substr(pem + 27);
                size_t pem_end = body.find("-----END CERTIFICATE-----");
                if (pem_end != std::string::npos) body = body.substr(0, pem_end);
            }
            std::string clean;
            for (char c : body) {
                if (!isspace((unsigned char)c)) clean.push_back(c);
            }
            if (!clean.empty()) {
                auto der = base64_decode(clean);
                if (!der.empty()) g_keybox_certs.push_back(std::move(der));
            }
            pos = b + tag_close.size();
        }
        if (!g_keybox_certs.empty()) {
            LOGD("keybox loaded: %zu certs from %s", g_keybox_certs.size(), p);
            return;
        }
    }
    LOGW("keybox.xml not found or no valid certificates");
}

// ---- libbinder 定位（用于 PLT hook ioctl） ----
static bool find_libbinder(dev_t *dev, ino_t *ino) {
    FILE *f = fopen("/proc/self/maps", "re");
    if (f == nullptr) return false;
    char line[512];
    bool found = false;
    while (fgets(line, sizeof(line), f) != nullptr) {
        unsigned long start, end, offset, inode;
        char perms[8] = {0};
        char devstr[32] = {0};
        char path[256] = {0};
        int n = sscanf(line, "%lx-%lx %7s %lx %31s %lu %255s",
                       &start, &end, perms, &offset, devstr, &inode, path);
        if (n >= 6 && strstr(path, "libbinder.so") != nullptr) {
            unsigned int major = 0, minor = 0;
            if (sscanf(devstr, "%x:%x", &major, &minor) == 2) {
                *dev = makedev(major, minor);
                *ino = static_cast<ino_t>(inode);
                found = true;
            }
            break;
        }
    }
    fclose(f);
    return found;
}

// ---- getKeyEntry 事务拦截 ----
static int (*real_ioctl)(int, unsigned long, ...) = nullptr;
static thread_local bool t_pending_getkeyentry = false;

static const char *KS2_DESCRIPTOR = "android.system.keystore2.IKeystoreService";
static const uint32_t GET_KEY_ENTRY_CODE = 2;  // getKeyEntry 事务码

// 检查 Parcel 开头是否为目标 interface token
static bool check_interface_token(const uint8_t *d, size_t sz) {
    if (d == nullptr || sz < 12) return false;
    int32_t len;
    memcpy(&len, d + 4, 4);
    if (len <= 0 || len > 200) return false;
    size_t need = 8 + (size_t)(len + 1) * 2;  // strict(4) + len(4) + utf16 + 结尾\0
    if (sz < need) return false;
    size_t want = strlen(KS2_DESCRIPTOR);
    if ((size_t)len != want) return false;
    const uint8_t *u = d + 8;
    for (size_t i = 0; i < want; i++) {
        uint16_t c = (uint16_t)(u[i * 2] | (u[i * 2 + 1] << 8));
        if (c != (uint8_t)KS2_DESCRIPTOR[i]) return false;
    }
    return true;
}

// 替换 reply Parcel 中的证书链为 keybox 证书链
static bool replace_reply_certs(struct binder_transaction_data *tr) {
    const uint8_t *d = (const uint8_t *)tr->data.ptr.buffer;
    size_t sz = tr->data_size;
    if (d == nullptr || sz < 40 || g_keybox_certs.empty()) return false;
    size_t pos = 0;
    auto rd32 = [&](int32_t &v) -> bool {
        if (pos + 4 > sz) return false;
        memcpy(&v, d + pos, 4); pos += 4; return true;
    };
    auto rd64 = [&](int64_t &v) -> bool {
        if (pos + 8 > sz) return false;
        memcpy(&v, d + pos, 8); pos += 8; return true;
    };
    int32_t v;
    if (!rd32(v) || v != 0) return false;   // status == OK
    if (!rd32(v) || v != 1) return false;   // KeyEntryResponse 对象标记
    if (!rd32(v) || v != 1) return false;   // KeyMetadata 对象标记
    if (!rd32(v) || v != 1) return false;   // KeyDescriptor 对象标记
    if (!rd32(v)) return false;             // domain
    int64_t v64;
    if (!rd64(v64)) return false;           // nspace
    if (!rd32(v)) return false;             // alias (String)
    if (v < 0) return false;                // alias 不应为 null
    if (pos + (size_t)(v + 1) * 2 > sz) return false;
    pos += (size_t)(v + 1) * 2;             // 跳过 alias utf16
    if (!rd32(v)) return false;             // blob (byte[])
    if (v == -1) { /* null */ }
    else if (v < 0 || pos + (size_t)v > sz) return false;
    else pos += (size_t)v;
    if (!rd32(v)) return false;             // keySecurityLevel
    size_t certs_start = pos;               // certificates 段起点（int32 N 处）
    if (!rd32(v)) return false;             // N
    if (v <= 0 || v > 64) return false;
    for (int i = 0; i < v; i++) {
        if (!rd32(v)) return false;
        if (v < 0 || v > 1048576 || pos + (size_t)v > sz) return false;
        pos += (size_t)v;
    }
    size_t certs_end = pos;
    // 构造新 certificates 段
    std::vector<uint8_t> newcerts;
    {
        uint32_t n = (uint32_t)g_keybox_certs.size();
        uint8_t h[4]; memcpy(h, &n, 4);
        newcerts.insert(newcerts.end(), h, h + 4);
        for (auto &c : g_keybox_certs) {
            uint32_t l = (uint32_t)c.size();
            uint8_t lh[4]; memcpy(lh, &l, 4);
            newcerts.insert(newcerts.end(), lh, lh + 4);
            newcerts.insert(newcerts.end(), c.begin(), c.end());
        }
    }
    int64_t delta = (int64_t)newcerts.size() - (int64_t)(certs_end - certs_start);
    size_t newsz = sz + (size_t)delta;
    uint8_t *nbuf = (uint8_t *)malloc(newsz);
    if (nbuf == nullptr) return false;
    memcpy(nbuf, d, certs_start);
    memcpy(nbuf + certs_start, newcerts.data(), newcerts.size());
    memcpy(nbuf + certs_start + newcerts.size(), d + certs_end, sz - certs_end);
    // 调整 binder 对象偏移（位于 certificates 段之后的都要 +delta）
    uint32_t *noffs = nullptr;
    if (tr->offsets_size > 0 && tr->data.ptr.offsets != nullptr) {
        size_t cnt = tr->offsets_size / 4;
        noffs = (uint32_t *)malloc(tr->offsets_size);
        if (noffs == nullptr) { free(nbuf); return false; }
        const uint8_t *o = (const uint8_t *)tr->data.ptr.offsets;
        for (size_t i = 0; i < cnt; i++) {
            uint32_t off;
            memcpy(&off, o + i * 4, 4);
            if (off > certs_start) off = (uint32_t)((int64_t)off + delta);
            memcpy(noffs + i, &off, 4);
        }
    }
    tr->data.ptr.buffer = nbuf;
    tr->data_size = newsz;
    if (noffs != nullptr) tr->data.ptr.offsets = noffs;
    LOGD("getKeyEntry reply certs replaced -> %zu certs", g_keybox_certs.size());
    return true;
}

static int fake_ioctl(int fd, unsigned long request, ...) {
    va_list ap;
    va_start(ap, request);
    void *arg = va_arg(ap, void *);
    va_end(ap);
    if (request == BINDER_WRITE_READ && arg != nullptr) {
        struct binder_write_read *bwr = (struct binder_write_read *)arg;
        // 写方向：检测 BC_TRANSACTION（getKeyEntry 请求）
        if (bwr->write_buffer != nullptr && bwr->write_consumed < bwr->write_size) {
            const uint8_t *wp = (const uint8_t *)bwr->write_buffer;
            uint32_t cmd;
            memcpy(&cmd, wp, 4);
            if (cmd == BC_TRANSACTION &&
                bwr->write_size - bwr->write_consumed >= 4 + sizeof(struct binder_transaction_data)) {
                const struct binder_transaction_data *tr =
                    (const struct binder_transaction_data *)(wp + 4);
                if (tr->code == GET_KEY_ENTRY_CODE && tr->data.ptr.buffer != nullptr &&
                    check_interface_token((const uint8_t *)tr->data.ptr.buffer, tr->data_size)) {
                    t_pending_getkeyentry = true;
                    LOGD("getKeyEntry request detected");
                }
            }
        }
        int ret = real_ioctl(fd, request, arg);
        // 读方向：检测 BR_REPLY，替换证书链
        if (t_pending_getkeyentry && bwr->read_buffer != nullptr && bwr->read_consumed >= 4) {
            t_pending_getkeyentry = false;
            const uint8_t *rp = (const uint8_t *)bwr->read_buffer;
            uint32_t rcmd;
            memcpy(&rcmd, rp, 4);
            if (rcmd == BR_REPLY &&
                bwr->read_consumed >= 4 + sizeof(struct binder_transaction_data)) {
                struct binder_transaction_data *rtr =
                    (struct binder_transaction_data *)(rp + 4);
                replace_reply_certs(rtr);
            }
        }
        return ret;
    }
    return real_ioctl(fd, request, arg);
}

// ================= 属性读取 hook（BL/TEE/root 伪装） =================
static int (*real_system_property_get)(const char *, char *) = nullptr;
static int fake_system_property_get(const char *name, char *value) {
    if (name != nullptr) {
        for (const auto &p : FAKE_PROPS) {
            if (strcmp(name, p.name) == 0) {
                if (value != nullptr) strcpy(value, p.value);
                return (int)strlen(p.value);
            }
        }
    }
    return real_system_property_get(name, value);
}

// ================= libc 定位 =================
static bool find_libc(dev_t *dev, ino_t *ino) {
    FILE *f = fopen("/proc/self/maps", "re");
    if (f == nullptr) return false;
    char line[512];
    bool found = false;
    while (fgets(line, sizeof(line), f) != nullptr) {
        unsigned long start, end, offset, inode;
        char perms[8] = {0};
        char devstr[32] = {0};
        char path[256] = {0};
        int n = sscanf(line, "%lx-%lx %7s %lx %31s %lu %255s",
                       &start, &end, perms, &offset, devstr, &inode, path);
        if (n >= 6 && strstr(path, "libc.so") != nullptr) {
            unsigned int major = 0, minor = 0;
            if (sscanf(devstr, "%x:%x", &major, &minor) == 2) {
                *dev = makedev(major, minor);
                *ino = static_cast<ino_t>(inode);
                found = true;
            }
            break;
        }
    }
    fclose(f);
    return found;
}

// ================= 模块主体 =================
class Aonself : public ModuleBase {
public:
    void onLoad(Api *api, JNIEnv *env) override {
        this->api = api;
        this->env = env;
        load_targets();
        load_keybox();
        LOGD("Aonself loaded, targets=%zu keybox_certs=%zu", targets.size(), g_keybox_certs.size());
    }

    void preAppSpecialize(AppSpecializeArgs *args) override {
        if (args->uid < 10000) return;
        if (api == nullptr) return;
        if (targets.empty()) return;
        std::string pkg = get_pkg(args);
        if (pkg.empty()) return;
        if (targets.count(pkg) == 0) return;  // 仅对 target.txt 中的包生效
        if (!hooks_registered) {
            hooks_registered = register_hooks();
            LOGD("hooks registered for %s", pkg.c_str());
        }
    }

    void postAppSpecialize(const AppSpecializeArgs *args) override {
        if (api != nullptr && hooks_registered) {
            api->pltHookCommit();
        }
    }

    void preServerSpecialize(ServerSpecializeArgs *args) override {}
    void postServerSpecialize(const ServerSpecializeArgs *args) override {}

private:
    Api *api = nullptr;
    JNIEnv *env = nullptr;
    bool hooks_registered = false;
    std::set<std::string> targets;

    // 读取 target.txt：优先 /data/adb/Aonself_Stealth/target.txt，回退模块目录
    void load_targets() {
        targets.clear();
        const char *paths[] = {
            "/data/adb/Aonself_Stealth/target.txt",
            "/data/adb/modules/Aonself_Stealth/target.txt",
        };
        for (const char *p : paths) {
            FILE *f = fopen(p, "re");
            if (f == nullptr) continue;
            LOGD("reading targets from %s", p);
            char line[1024];
            while (fgets(line, sizeof(line), f) != nullptr) {
                // 去掉行尾空白
                char *e = line + strlen(line) - 1;
                while (e >= line && (*e == '\n' || *e == '\r' || *e == ' ' || *e == '\t')) *e-- = '\0';
                // 跳过空行和注释
                if (line[0] == '\0' || line[0] == '#') continue;
                // 支持逗号分隔
                char *save = nullptr;
                for (char *tok = strtok_r(line, ",", &save); tok != nullptr;
                     tok = strtok_r(nullptr, ",", &save)) {
                    char *s = tok;
                    while (*s == ' ' || *s == '\t') s++;
                    size_t len = strlen(s);
                    while (len > 0 && (s[len-1] == ' ' || s[len-1] == '\t')) s[--len] = '\0';
                    if (s[0] != '\0' && s[0] != '#') {
                        targets.insert(s);
                    }
                }
            }
            fclose(f);
            if (!targets.empty()) break;
        }
    }

    std::string get_pkg(AppSpecializeArgs *args) const {
        if (env != nullptr && args->app_data_dir != nullptr) {
            const char *d = env->GetStringUTFChars(args->app_data_dir, nullptr);
            if (d != nullptr) {
                std::string s(d);
                env->ReleaseStringUTFChars(args->app_data_dir, d);
                size_t p = s.rfind('/');
                return (p != std::string::npos) ? s.substr(p + 1) : s;
            }
        }
        if (env != nullptr && args->nice_name != nullptr) {
            const char *n = env->GetStringUTFChars(args->nice_name, nullptr);
            if (n != nullptr) {
                std::string s(n);
                env->ReleaseStringUTFChars(args->nice_name, n);
                return s;
            }
        }
        return "";
    }

    bool register_hooks() {
        dev_t dev = 0;
        ino_t ino = 0;
        if (!find_libc(&dev, &ino)) {
            LOGW("libc not found, hooks skipped");
            return false;
        }
        api->pltHookRegister(dev, ino, "openat", reinterpret_cast<void *>(fake_openat),
                             reinterpret_cast<void **>(&real_openat));
        api->pltHookRegister(dev, ino, "open", reinterpret_cast<void *>(fake_open),
                             reinterpret_cast<void **>(&real_open));
        api->pltHookRegister(dev, ino, "stat", reinterpret_cast<void *>(fake_stat),
                             reinterpret_cast<void **>(&real_stat));
        api->pltHookRegister(dev, ino, "lstat", reinterpret_cast<void *>(fake_lstat),
                             reinterpret_cast<void **>(&real_lstat));
        api->pltHookRegister(dev, ino, "fstatat", reinterpret_cast<void *>(fake_fstatat),
                             reinterpret_cast<void **>(&real_fstatat));
        api->pltHookRegister(dev, ino, "access", reinterpret_cast<void *>(fake_access),
                             reinterpret_cast<void **>(&real_access));
        api->pltHookRegister(dev, ino, "faccessat", reinterpret_cast<void *>(fake_faccessat),
                             reinterpret_cast<void **>(&real_faccessat));
        api->pltHookRegister(dev, ino, "readlink", reinterpret_cast<void *>(fake_readlink),
                             reinterpret_cast<void **>(&real_readlink));
        api->pltHookRegister(dev, ino, "readlinkat", reinterpret_cast<void *>(fake_readlinkat),
                             reinterpret_cast<void **>(&real_readlinkat));
        api->pltHookRegister(dev, ino, "__system_property_get",
                             reinterpret_cast<void *>(fake_system_property_get),
                             reinterpret_cast<void **>(&real_system_property_get));
        // keybox: hook libbinder 的 ioctl（拦截 keystore2 getKeyEntry）
        dev_t bdev = 0;
        ino_t bino = 0;
        if (find_libbinder(&bdev, &bino)) {
            api->pltHookRegister(bdev, bino, "ioctl", reinterpret_cast<void *>(fake_ioctl),
                                 reinterpret_cast<void **>(&real_ioctl));
            LOGD("libbinder ioctl hook registered");
        } else {
            LOGW("libbinder not found, keybox hook skipped");
        }
        return true;
    }
};

REGISTER_ZYGISK_MODULE(Aonself)
